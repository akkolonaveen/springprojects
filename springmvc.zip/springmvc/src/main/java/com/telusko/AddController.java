package com.telusko;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AddController {

	
	
	@RequestMapping("/add")
	public ModelAndView add(HttpServletRequest req,HttpServletResponse res)
	
	{
		ModelAndView mv=new ModelAndView();
		String user=req.getParameter("uname");
		String pass=req.getParameter("pass");
		
		
		if(user.equals("ram")&&pass.equals("123"))
		{
			mv.setViewName("display");
		}
		else
		{
			mv.setViewName("index");
		}
		
		
		return mv;
	}
}
