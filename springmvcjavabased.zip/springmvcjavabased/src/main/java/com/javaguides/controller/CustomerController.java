package com.javaguides.controller;

import javax.validation.Valid;

import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javaguides.model.Customer;
import com.sun.javafx.sg.prism.NGShape.Mode;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	@InitBinder
	public void InitBinder(WebDataBinder db) {
		StringTrimmerEditor sted = new StringTrimmerEditor(true);
		db.registerCustomEditor(String.class, sted);
	}

	@RequestMapping("/showform")
	public String showform(Model model) {
		model.addAttribute("cust", new Customer());
		return "customerform";

	}
@RequestMapping("/process")
	public String process(@Valid @ModelAttribute("cust") Customer cu,BindingResult br)
	{
		
		
		if(br.hasErrors())
		{
			return "customerform";
		}
		else
			
			return "customerconfirm";
		
	}

}
