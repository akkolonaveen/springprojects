package com.javaguides.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.javaguides.model.SignUpform;
import com.sun.javafx.sg.prism.NGShape.Mode;

@Controller
public class SignUpController {

	@ModelAttribute("sf")
	public SignUpform sign()
	{
		return new SignUpform();
	}
	@GetMapping("/showform")
	public String show()
	{
		return "signup";
	}
	@PostMapping("/saveform")
	public String save(@ModelAttribute("sf") SignUpform st,Model model)
	{
		System.out.println("firtname= "+st.getFirstName());
		System.out.println("lastyname= "+st.getLastName());
		System.out.println("email = "+st.getEmail());
		System.out.println("username = "+st.getUserName());
		System.out.println("password= "+st.getPassword());
		model.addAttribute("user",st);
		return "success";
		
		
	}
	
	
	
}
