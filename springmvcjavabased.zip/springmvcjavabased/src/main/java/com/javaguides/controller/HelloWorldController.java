package com.javaguides.controller;

import java.time.LocalDateTime;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
public class HelloWorldController {
	/*
	 * @RequestMapping("/hello") public String handler(Model model) { HelloWorld
	 * hw=new HelloWorld(); hw.setMessage("hello spring mvc java");
	 * hw.setDateofTime(LocalDateTime.now().toString()); model.addAttribute("h",hw);
	 * return "helloworld";
	 * 
	 * }
	 */
	
	@RequestMapping("/log")
	@ResponseBody
public String log()
{
	return "login successful";
}
	@ResponseBody
@RequestMapping("/home")	
public String move()
{
	return "welcome home";
}
}
