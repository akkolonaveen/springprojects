package com.javaguides.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

import com.sun.istack.internal.NotNull;
@Entity
@Table
public class Customer {
	
	@NotNull
	@Min(value=1)
	@Max(value=4)
	private int cid;
	@NotNull
	@Size(min=1,max=8)
	private String cname;
	@NotNull
	@Email(message="invalid !enter again")
	private String email;
	@NotNull
	@Pattern(regexp="[a-zA-Z0-9]",message="only 6chars/digit")
	private String postal;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPostal() {
		return postal;
	}
	public void setPostal(String postal) {
		this.postal = postal;
	}
	
	

}
