package com.javaguides.model;

public class HelloWorld {
	private String message;
	private String dateofTime;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDateofTime() {
		return dateofTime;
	}
	public void setDateofTime(String dateofTime) {
		this.dateofTime = dateofTime;
	}
	
	
	
	
	
	

}
