import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationService {



  constructor(private http:HttpClient) { }
public doregistration(user){
return this.http.post("http://localhost:8030/register",user,{responseType:'text' as 'json'});


}
public getUsers(){
  return this.http.get("http://localhost:8030/getallusers");
  
}  

public getUserByEmail(email){
  return this.http.get("http://localhost:8030/finduser/"+email);
  
}  
public deleteUser(id){
  return this.http.delete("http://localhost:8030/cancel/"+id);
  
}  

public updateUser(id){
  return this.http.delete("http://localhost:8030/update");
  
}  


}
