package com.telusko;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
		ApplicationContext con=new AnnotationConfigApplicationContext(AppConfig.class);
		  //Bike b= (Bike) con.getBean("bike");
			/*
			 * Car c= (Car) con.getBean("car"); b.show(); c.show(); Tyre t= (Tyre)
			 * con.getBean("tyre"); System.out.println(t);
			 */
		/*
		 * Samsung s1=con.getBean(Samsung.class); s1.config();
		 */
		  
		Bike b=(Bike) con.getBean("bike");
		b.show();
		  }

}
