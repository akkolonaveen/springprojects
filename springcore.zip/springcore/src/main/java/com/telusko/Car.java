package com.telusko;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


public class Car {

	
	
	private Tyre tyre;
	public void show()
	{
		System.out.println("car moving"+tyre);
	}
}
