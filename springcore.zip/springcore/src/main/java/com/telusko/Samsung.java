package com.telusko;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;


@Component
public class Samsung {
	
	
	@Autowired
	@Qualifier("android")
	Mobile mob;
	

	public Mobile getMob() {
		return mob;
	}


	public void setMob(Mobile mob) {
		this.mob = mob;
	}


	public void config()
	{
		System.out.println("samsung configuration ");
		mob.process();
	}

}
