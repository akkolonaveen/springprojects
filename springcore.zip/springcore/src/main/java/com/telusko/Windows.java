package com.telusko;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class Windows implements Mobile {

	@Override
	public void process() {
	System.out.println("wiondows is 2nbd smartphonme");
		
	}

}
