package com.telusko;

public interface Mobile {

	void process();
	
}
