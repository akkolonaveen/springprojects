package com.telusko;

public class Tyre {

	
	private String brand;
	private int tid;
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	
	public Tyre(String brand, int tid) {
		super();
		this.brand = brand;
		this.tid = tid;
	}
	@Override
	public String toString() {
		return "Tyre [brand=" + brand + ", tid=" + tid + "]";
	}
	
	
	
}
