package com.telusko;

import org.springframework.stereotype.Component;

@Component
public class Android implements Mobile{

	@Override
	public void process() {
		System.out.println("android phone ");
		
	}

}
