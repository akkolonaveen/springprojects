package com.telusko;

import org.springframework.stereotype.Component;

@Component
public class Bike {
	
	public void show()
	{
		System.out.println("bike moving");
	}
}

