package com.telusko;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages ="com.telusko")
public class AppConfig {
	
	
	/*
	 * @Bean public Samsung get() { return new Samsung(); }
	 * 
	 * @Bean public Mobile getin() { return new Android(); }
	 */

	 @Bean public Bike get() { return new Bike();} 
	
	
}
