package com.angular;

public class Book {
	
	
	private int id;
	private String bname;
	private String bauthor;
	private int bprice;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public String getBauthor() {
		return bauthor;
	}
	public void setBauthor(String bauthor) {
		this.bauthor = bauthor;
	}
	public int getBprice() {
		return bprice;
	}
	public void setBprice(int bprice) {
		this.bprice = bprice;
	}
	public Book(int id, String bname, String bauthor, int bprice) {
		super();
		this.id = id;
		this.bname = bname;
		this.bauthor = bauthor;
		this.bprice = bprice;
	}
	

}
