package com.telusko.demo;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.demo.dao.AlienRepo;



@RestController
@CrossOrigin(origins="*")
public class HomeController {
	
	
	@Autowired
	AlienRepo repo;

	@RequestMapping("home")
	
	public ModelAndView home(Alien aa)
	{
		
		ModelAndView mv=new ModelAndView();
		mv.addObject("a", aa);
		mv.setViewName("home");
		return mv;
	}
	
	@RequestMapping("/addalien")
	public String add(Alien a)
	{
		
		repo.save(a);
		return "home";
	}
	@RequestMapping(path="/aliens")
	@ResponseBody
	public List<Alien> get()
	{
		return (List<Alien>) repo.findAll();
	}
	
	
	@GetMapping("/alien/{aid}")
	@ResponseBody
	public Optional<Alien> getid(@PathVariable("aid") int aid)
	{
		
		return repo.findById(aid);
	}
	@PostMapping(path="/alien")
	public Alien post(@RequestBody Alien a)
	{
		
		repo.save(a);
		return a;
	}
	
	
	@DeleteMapping("/alien/{aid}")
	@ResponseBody
	public String delete(@PathVariable("aid") int aid)
	{
		 repo.deleteById(aid);
		 return "deleted";
	}
	
	@PutMapping("/alien")
	@ResponseBody
	public Alien update(@RequestBody Alien a)
	{
		return  repo.save(a);
		
	}
	
}
