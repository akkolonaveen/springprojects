package com.telusko.demo;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class SpringbootdemoApplication {
	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/findallbooks")
	public List<Book> getBooks()
	{
		
		
		return Stream.of(new Book(101,"java",1000),new Book(102,"python",1500),new Book(103,"ds",2000),
				new Book(104,"golang",1200)).collect(Collectors.toList());
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdemoApplication.class, args);
		System.out.println("hello spring boot");
	}

}
