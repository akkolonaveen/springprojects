insert into alien values(101,'navin','java');
insert into alien values(102,'kiran','python');
insert into alien values(103,'ram','ai');
insert into alien values(104,'janu','ml');
insert into student values(101,'rani','java');
insert into student values(102,'suraj','python');
insert into student values(103,'david','ai');
insert into student values(104,'john','ml');
