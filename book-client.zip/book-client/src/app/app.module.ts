import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import {HttpClientModule } from '@angular/common/http';
import { TotalPipe } from './total.pipe';

@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    TotalPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
