import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  getProducts()
  {
   return [
      {
        "id":7852,
        "name":"latop",
        "brand":"dell",
        "price":45000
      },
      {
        "id":8798,
        "name":"pc",
        "brand":"mac",
        "price":85000
      }

    ]
  }

  constructor() { }
}
