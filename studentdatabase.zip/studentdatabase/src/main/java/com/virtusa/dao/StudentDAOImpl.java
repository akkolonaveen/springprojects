package com.virtusa.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.entity.Student;

@Repository
public class StudentDAOImpl  implements StudentDAO{

	@Autowired
	private SessionFactory sf;
	@Override
	public void saveStudentObj(Student std) {
		sf.getCurrentSession().saveOrUpdate(std);
		
	}
	@Override
	public List<Student> getallstudents() {
		return sf.getCurrentSession().createQuery("from Student").list();
	
	}
	@Override
	public Student getstudentbyid(Integer studentId) {
		Student std=(Student)sf.getCurrentSession().get(Student.class,studentId);
		return std;
	}
	@Override
	public void deleteobj(Student stddel) {
  sf.getCurrentSession().delete(stddel);		
	}

}
