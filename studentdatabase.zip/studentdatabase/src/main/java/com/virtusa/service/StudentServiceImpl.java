package com.virtusa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.dao.StudentDAO;
import com.virtusa.entity.Student;
@Service
public  class StudentServiceImpl  implements StudentService{

	@Autowired
	private StudentDAO studentDAO;
	
	@Override
	@Transactional
	public void saveStudentObj(Student std) {
		studentDAO.saveStudentObj(std);
		
		
	}

	@Override
	@Transactional
	public List<Student> getallstudents() {
		// TODO Auto-generated method stub
		return studentDAO.getallstudents();
	}

	@Override
	@Transactional
	public Student getstudentobj(Integer studentId) {
		return studentDAO.getstudentbyid(studentId);
		
	}

	@Override
	@Transactional
	public void deleteobj(Student stddel) {
   studentDAO.deleteobj(stddel);		
	}

}
